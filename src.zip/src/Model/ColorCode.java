package Model;

public enum ColorCode
{
    RED,GREEN,BLUE
}
